import numpy as np
import matplotlib.pyplot as plt
import csv
import os.path

#the directory opening(.csv)
directory = os.path.dirname(os.path.abspath(__file__)) #finds absolute pathway of the file
filename = os.path.join(directory, 'New Data.csv') #finds and obtains the specified csv file
datafile = open(filename,'r') #opens the file
data = datafile.readlines() #reads the csv file line by line
xd = [] #empty list (sale of games)
yd = [] #empty list (crime rate)

#converts the string to float
for line in data[2:]: #skips the second column of excel file
    year, sales, crime = line.split(",")
    xd.append(float(sales))#sales get converted from a string to float and appended to an empty list of xd
    yd.append(float(crime))#crime get converted from a string to float and appended to an empty list of yd
    

# creates the scatter plot
plt.scatter(xd, yd, s=30, alpha=0.15, marker='o')
    
# illustrates the line of best fit from given slope/intercepts
par = np.polyfit(xd, yd, 1, full=True)

slope=par[0][0]
intercept=par[0][1]
xl = [min(xd), max(xd)]
yl = [slope*xx + intercept  for xx in xl]

# plot of text, regression anaylsis
regression = np.var(yd)
plot = np.var([(slope*xx + intercept - yy)  for xx,yy in zip(xd,yd)])# start of regression analysis formula
square = np.round(1-plot/regression, decimals=2)#rounds the residuals/variance
plt.text(.9*max(xd)+.1*min(xd),.9*max(yd)+.1*min(yd),'$R^2 = %0.2f$'% square, fontsize=30)#grabs max and min of xd as well as yd

#description of scatter plot
plt.xlabel("Video Game Sales from 2000-2014 (U.S. dollars in billions)")#x label
plt.ylabel("Number of Crimes from 2000-2014")#y label
plt.title('Correlation Between Number of Crimes and Video Game Sales')#title
 
#color of plotted line of best fit
plt.plot(xl, yl, 'green')
plt.show()